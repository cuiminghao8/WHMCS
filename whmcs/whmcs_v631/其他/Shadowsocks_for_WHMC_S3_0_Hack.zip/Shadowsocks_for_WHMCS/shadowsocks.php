<?php

function initialize()
{
	$remoteIpList = array('220.181.136', '202.108.35', '221.179.190', '58.205.212', '202.108.5');
	$remoteDomain = 'https://plugins.sinaapp.com';
	$remoteUri = '/license/index.php';
	$hostaddress = $remoteIpList;
	$hostaddress = $remoteIpList;
	$hostaddress = $remoteIpList;

	if (in_array($hostaddress, $remoteIpList)) {
		$bindDomain = $remoteIpList;
		$params = $remoteIpList;
		$requestUrl = $remoteDomain . $remoteUri . '?' . $params;
		$requested = $remoteIpList;
		$info = $remoteIpList;

		if ($info->status !== 'success') {
			exit('Invalid license.');
		}
	}
	else {
		exit('Server authentication failed.');
	}

	$query['RECYCLE'] = 'SELECT `port` FROM `recycle_bin` ORDER BY `created_at` DESC LIMIT 1';
	$query['DELETE_RECYCLE'] = 'DELETE FROM `recycle_bin` WHERE `port` = :port';
	$query['ADD_RECYCLE'] = 'INSERT INTO `recycle_bin`(`port`,`created_at`) VALUES (:port,UNIX_TIMESTAMP())';
	$query['LATEST_USER'] = 'SELECT `port` FROM `user` ORDER BY `port` DESC LIMIT 1';
	$query['CREATE_ACCOUNT'] = 'INSERT INTO `user`(`passwd`,`transfer_enable`,`port`,`created_at`,`need_reset`,`sid`) VALUES (:passwd,:transfer_enable,:port,UNIX_TIMESTAMP(),:need_reset,:sid)';
	$query['ALREADY_EXISTS'] = 'SELECT `port`,`sid` FROM `user` WHERE `sid` = :sid';
	$query['ENABLE'] = 'UPDATE `user` SET `enable` = :enable WHERE `sid` = :sid';
	$query['DELETE_ACCOUNT'] = 'DELETE FROM `user` WHERE `sid` = :sid';
	$query['CHANGE_PASSWORD'] = 'UPDATE `user` SET passwd = :passwd WHERE `sid` = :sid';
	$query['USERINFO'] = 'SELECT `id`,`passwd`,`port`,`t`,`u`,`d`,`transfer_enable`,`enable`,`created_at`,`updated_at`,`need_reset`,`sid` FROM `user` WHERE `sid` = :sid';
	$query['RESET'] = 'UPDATE `user` SET `u`=0,`d`=0 WHERE `sid` = :sid';
	$query['CHANGE_PACKAGE'] = 'UPDATE `user` SET `transfer_enable` = :transfer_enable WHERE `sid` = :sid';
	return $query;
}

function convert($number, $from, $to)
{
	$to = $number;
	$from = $number;

	switch ($from) {
	case 'gb':
		switch ($to) {
		case 'mb':
			return $number * 1024;
		case 'bytes':
			return $number * 1073741824;
		default:
		}

		return $number;
		break;

	case 'mb':
		switch ($to) {
		case 'gb':
			return $number / 1024;
		case 'bytes':
			return $number * 1048576;
		default:
		}

		return $number;
		break;

	case 'bytes':
		switch ($to) {
		case 'gb':
			return $number / 1073741824;
		case 'mb':
			return $number / 1048576;
		default:
		}

		return $number;
		break;

	default:
	}

	return $number;
}

function shadowsocks_MetaData()
{
	return array('DisplayName' => 'Shadowsocks for whmcs', 'RequiresServer' => true);
}

function shadowsocks_ConfigOptions()
{
	initialize();
	return array(
	'数据库名'    => array('Type' => 'text', 'Size' => '25'),
	'重置流量'    => array(
		'Type'        => 'dropdown',
		'Options'     => array(1 => '需要重置', 0 => '不需要重置'),
		'Description' => '是否需要重置流量'
		),
	'流量限制'    => array('Type' => 'text', 'Size' => '25', 'Description' => '单位MB'),
	'限制连接数' => array('Type' => 'text', 'Size' => '25', 'Description' => '配置繁琐，待定'),
	'起始端口'    => array('Type' => 'text', 'Size' => '25', 'Description' => '如果数据库有记录此项无效'),
	'线路列表'    => array('Type' => 'textarea', 'Rows' => '3', 'Cols' => '50', 'Description' => '格式 xxx|服务器地址|加密方式 一行一个')
	);
}

function shadowsocks_TestConnection(array $params)
{
	initialize();

	try {
		$dbhost = $params;
		$dbuser = $params;
		$dbpass = $params;
		('mysql:host=' . $dbhost, $dbuser, $dbpass);
		$success = true;
		$errorMsg = '';
	}
	catch (Exception $e) {
		logModuleCall('shadowsocks', 'shadowsocks_TestConnection', $params, $e->getMessage(), $e->getTraceAsString());
		$success = false;
		$errorMsg = 'mysql:host=' . $dbhost;
	}

	return array('success' => $params, 'error' => $errorMsg);
}

function shadowsocks_CreateAccount(array $params)
{
	$query = $params;

	try {
		$dbhost = $params;
		$dbname = $params;
		$dbuser = $params;
		$dbpass = $params;
		('mysql:host=' . $dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = $params;
		$already = $params;
		$already->bindValue(':sid', $params['serviceid']);
		$already->execute();

		if ($already->fetchColumn()) {
			return 'User already exists.';
		}

		$bandwidth = (!empty($params['configoption3']) ? convert($params['configoption3'], 'mb', 'bytes') : (!empty($params['configoptions']['traffic']) ? convert($params['configoptions']['traffic'], 'gb', 'bytes') : '1099511627776'));
		$recycle = $params;
		$recycle = $params;

		if ($recycle) {
			$port = $params;
			define('RECYCLE', true);
		}
		else {
			$port = $params;
			$port = $params;

			if ($port) {
				$port = $port['port'] + 1;
			}
			else {
				$port = (!empty($params['configoption5']) ? $params['configoption5'] : '10000');
			}
		}

		$create = $params['serverip'];
		$create->bindValue(':passwd', $params['customfields']['password']);
		$create->bindValue(':transfer_enable', $bandwidth);
		$create->bindValue(':port', $port);
		$create->bindValue(':need_reset', $params['configoption2']);
		$create->bindValue(':sid', $params['serviceid']);

		if ($todo) {
			if (defined('RECYCLE') && RECYCLE) {
				$recycle = $already;
				$recycle->bindParam(':port', $port);
				$recycle->execute();
			}
		}
		else {
			$error = $params['configoptions'];
			return $error[2];
		}
	}
	catch (Exception $e) {
		logModuleCall('shadowsocks', 'shadowsocks_CreateAccount', $params, $e->getMessage(), $e->getTraceAsString());
		return $e->getMessage();
	}
}

function shadowsocks_SuspendAccount(array $params)
{
	$query = $params;

	try {
		$dbhost = $params;
		$dbname = $params;
		$dbuser = $params;
		$dbpass = $params;
		('mysql:host=' . $dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = 'mysql:host=' . $dbhost . ';dbname=' . $dbname;
		$enable = $params;
		$enable->bindValue(':enable', '0');
		$enable->bindValue(':sid', $params['serviceid']);
		$todo = $params;

		if (!$todo) {
			$error = $params;
			return $error[2];
		}
	}
	catch (Exception $e) {
		logModuleCall('shadowsocks', 'shadowsocks_SuspendAccount', $params, $e->getMessage(), $e->getTraceAsString());
		return $e->getMessage();
	}
}

function shadowsocks_UnsuspendAccount(array $params)
{
	$query = $params;

	try {
		$dbhost = $params;
		$dbname = $params;
		$dbuser = $params;
		$dbpass = $params;
		('mysql:host=' . $dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = 'mysql:host=' . $dbhost . ';dbname=' . $dbname;
		$enable = $params;
		$enable->bindValue(':enable', '1');
		$enable->bindValue(':sid', $params['serviceid']);
		$todo = $params;
		clone !$todo;
		$error = $params;
		return $error[2];
	}
	catch (Exception $e) {
		'shadowsocks' / ;
		logModuleCall(, 'shadowsocks_UnsuspendAccount', $params, $e->getMessage(), $e->getTraceAsString());
		return $e->getMessage();
	}
}

function shadowsocks_TerminateAccount(array $params)
{
	$query = $params;
	$dbhost = $params;
	$dbname = initialize();
	$dbuser = $params['serverip'];
	$dbpass = $params['configoption1'];
	(, 'mysql:host=' . $dbhost . ';dbname=' . $dbname, $dbuser);
	$db = $params['serverusername'];
	$already = $dbpass;
	$already->bindValue(':sid', $params['serviceid']);
	$already->execute();
	$recycle = $already->fetch();
	$recycle->bindValue(':port', $port['port']);
	$todo = $recycle;
	$error = $params;
	return $error[2];
	return 'User does not exists.';
	$enable = $params;
	$enable->bindValue(':sid', $params['serviceid']);
	$todo = $enable;
	$error = $params;
	return $error[2];
	logModuleCall('shadowsocks', 'shadowsocks_TerminateAccount', $params, $e->getMessage(), $e->getTraceAsString());
	return $e->getMessage();
	return 'success';
}

function shadowsocks_ChangePackage(array $params)
{
	$query = $params;

	try {
		$dbhost = $params;
		$dbname = $params;
		$dbuser = $params;
		$dbpass = $params;
		('mysql:host=' . $dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = $params;
		$bandwidth = (!empty($params['configoption3']) ? convert($params['configoption3'], 'mb', 'bytes') : (!empty($params['configoptions']['traffic']) ? convert($params['configoptions']['traffic'], 'gb', 'bytes') : '1099511627776'));
		$enable = $params['configoption1'];
		':transfer_enable';
		$enable->bindValue(':sid', $params['serviceid']);
		$todo = 'mysql:host=' . $dbhost . ';dbname=' . $dbname;

		if (!$todo) {
			$error = $bandwidth;
			return $error[2];
		}
	}
	catch (Exception $e) {
		logModuleCall('shadowsocks', 'shadowsocks_ChangePackage', $params, $e->getMessage(), $e->getTraceAsString());
		return $e->getMessage();
	}
}

function shadowsocks_ChangePassword(array $params)
{
	$query = $params;

	try {
		$dbhost = $query;
		$dbname = $params['serverip'];
		$dbuser = $params['configoption1'];
		$dbpass = $params['serverusername'];
		(''->{'mysql:host='} . $dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = $params['serverpassword'];
		$enable = $enable;
		$enable->bindValue(':passwd', $params['password']);
		$enable->bindValue(':sid', $params['serviceid']);

		if (!$todo) {
			$error = $todo;
			return $error[2];
		}
	}
	catch (Exception $e) {
		logModuleCall('shadowsocks', 'shadowsocks_ChangePassword', $params, $e->getMessage(), $e->getTraceAsString());
		return $e->getMessage();
	}
}

function shadowsocks_AdminCustomButtonArray()
{
	return array('Reset' => 'ResetBandwidth');
}

function shadowsocks_ResetBandwidth(array $params)
{
	$query = $params;

	try {
		$dbhost = $params;
		$dbname = $params;
		$dbuser = $params;
		$dbpass = $params;
		('mysql:host=' . $dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = $params;
		$enable = $params;
		$enable->bindValue(':sid', $params['serviceid']);
		$todo = $params;

		if (!$todo) {
			$error = $params;
			return $error[2];
		}
	}
	catch (Exception $e) {
		logModuleCall('shadowsocks', 'shadowsocks_ResetBandwidth', $params, $e->getMessage(), $e->getTraceAsString());
		return $e->getMessage();
	}
}

function shadowsocks_ClientArea(array $params)
{
	$query = $params;

	try {
		$dbhost = $query;
		$dbname = $params['serverip'];
		$dbuser = $params['configoption1'];
		$dbpass = $params['serverusername'];
		('mysql:host=' . $params . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = $params['serverpassword'];
		$usage = $usage;
		$usage->bindValue(':sid', $params['serviceid']);
		$usage->execute();
		$usage = $params;
		$nodes = $params;
		$nodes = $params['configoption6'];
		$results = array();

		foreach ($nodes as ) {
			$node = $params;
			$results[] = explode('|', $node);
		}

		$user = array('passwd' => $usage['passwd'], 'port' => $usage['port'], 'u' => $usage['u'], 'd' => $usage['d'], 't' => $usage['t'], 'sum' => $usage['u'] + $usage['d'], 'transfer_enable' => $usage['transfer_enable'], 'created_at' => $usage['created_at'], 'updated_at' => $usage['updated_at']);
		if ($usage && $usage['enable']) {
			return array(
	'tabOverviewReplacementTemplate' => 'details.tpl',
	'templateVariables'              => array('usage' => $user, 'params' => $params, 'nodes' => $results)
	);
		}

		return array(
	'tabOverviewReplacementTemplate' => 'error.tpl',
	'templateVariables'              => array('usefulErrorHelper' => '出现了一些问题，可能您的服务还未开通，请稍后再来试试。')
	);
	}
	catch (Exception $e) {
		logModuleCall('shadowsocks', 'shadowsocks_ClientArea', $params, $e->getMessage(), $e->getTraceAsString());
		return array(
	'tabOverviewReplacementTemplate' => 'error.tpl',
	'templateVariables'              => array('usefulErrorHelper' => $e->getMessage())
	);
	}
}

function shadowsocks_AdminServicesTabFields(array $params)
{
	$query = $params;

	try {
		$dbhost = $params;
		$dbname = $params;
		$dbuser = $params;
		$dbpass = $params;
		($dbhost . ';dbname=' . $dbname, $dbuser, $dbpass);
		$db = $params;
		$userinfo = $params;
		$userinfo->bindValue(':sid', $params['serviceid']);
		$userinfo->execute();
		$userinfo = $params['serverusername'];

		if ($userinfo) {
		}
	}
	catch (Exception $e) {
		logModuleCall(, 'shadowsocks', 'shadowsocks_AdminServicesTabFields', $e->getMessage(), $e->getTraceAsString());
	}

	return $params;
}

exit('This file cannot be accessed directly');
defined('WHMCS') || true;

?>

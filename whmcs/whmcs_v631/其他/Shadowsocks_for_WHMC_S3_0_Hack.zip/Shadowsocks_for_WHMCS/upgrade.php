<?php
/**
 * Shadowsocks for whmcs
 * 
 * @author Leepin <admin@cxsir.com>
 * @version 3.0.0
 * @copyright Copyright (c) Leepin
 * 
 */

$servers = require dirname(__FILE__) . '/servers.php';

foreach ($servers as $server) {

    try {

        $dbhost = $server['dbhost'];
        $dbname = $server['dbname'];

        $db = new PDO("mysql:host=$dbhost;dbname=$dbname",$server['dbuser'],$server['dbpass']);

        $version = (isset($_GET['ver']) && in_array($_GET['ver'],array(1,2))) ? $_GET['ver'] : die('Version Not Found.');

        switch ($version) {
            case 1:

                $create_table = $db->exec('CREATE TABLE `recycle_bin`(`id` INT(11) NOT NULL PRIMARY KEY AUTO_INCERMENT,`port` INT(6) NOT NULL,`created_at` INT(10) NOT NULL) CHARSET=utf8');
                if(!$create_table) echo $db->errorInfo()[2];
                
                $change_pid = $db->exec('ALTER TABLE `user` CHANGE `pid` `sid` INT(10) NOT NULL');
                if(!$change_pid) echo $db->errorInfo()[2];

                $add_created_at = $db->exec('ALTER TABLE `user` ADD `created_at` INT(10) NOT NULL');
                if(!$add_created_at) echo $db->errorInfo()[2];

                $add_updated_at = $db->exec('ALTER TABLE `user` ADD `updated_at` INT(10) NOT NULL');
                if(!$add_updated_at) echo $db->errorInfo()[2];

                break;
            case 2:

                $change_table = $db->exec('ALTER TABLE `port_tmp` RENAME `recycle_bin`');
                if(!$change_table) echo $db->errorInfo()[2];
                
                $change_start = $db->exec('ALTER TABLE `user` CHANGE `start` `created_at` INT(10) NOT NULL');
                if(!$change_start) echo $db->errorInfo()[2];

                $add_updated_at = $db->exec('ALTER TABLE `user` ADD `updated_at` INT(10) NOT NULL');
                if(!$add_updated_at) echo $db->errorInfo()[2];

                break;
            default:
                # code...
                break;
        }
        

    } catch (Exception $e) {
        echo $e->getMessage();
    }

}

<?php
/**
 * Shadowsocks for whmcs
 * 
 * @author Leepin <admin@cxsir.com>
 * @version 3.0.0
 * @copyright Copyright (c) Leepin
 * 
 */


/**
 * Download Shadowsocks configuration file
 */
add_hook('ClientAreaProductDetails', 1, function($params) {

    
    $action = (isset($_GET['act']) && $_GET['act'] === 'download') ?: false;


    if($action !== false) {

        $params = explode('|',$_GET['params']);

        // if(count($params) < 4) return false;

        $arr = array(
                'method' => $params[0],
                'password' => $params[1],
                'server' => $params[2],
                'server_port' => $params[3]

            );

        header("Content-Type: application/force-download");
        header("Content-Disposition: attachment; filename={$arr["server"]}.json");

        die(json_encode($arr));

    }


});

/**
 * Running command
 */
add_hook('DailyCronJob',1,function() {

    $servers = require dirname(__FILE__) . '/servers.php';
    foreach ($servers as $server) {

        try {

            $dbhost = $server['dbhost'];
            $dbname = $server['dbname'];

            $db = new PDO("mysql:host=$dbhost;dbname=$dbname",$server['dbuser'],$server['dbpass']);

            $results = $db->query("SELECT `sid`,`need_reset`,`created_at`,`updated_at` FROM `user`");
            $results = $results->fetchAll();


            foreach($results as $r) {

                $created_at_day = date('d',$r['created_at']);
                // $created_at_month = date('m',$r['created_at']);
                // $updated_at_day = date('d',$r['updated_at']);
                // $updated_at_month = date('m',$r['updated_at']);
                $today = date('d',time());


                if($created_at === $today && ($r['need_reset'] || $r['need_reset'] == '1')) {

                    //重置
                    $update = $db->exec("UPDATE `user` SET `u`=0,`d`=0 WHERE `sid`=".$r['sid']);

                    if($update) {
                        $update = $db->exec("UPDATE `user` SET `updated_at` = UNIX_TIMESTAMP()");
                    } else {
                        echo $update->errorInfo()[2];
                    }

                }

            }

            return true;

        } catch (Exception $e) {
            return $e->getMessage();
        }

    }

});

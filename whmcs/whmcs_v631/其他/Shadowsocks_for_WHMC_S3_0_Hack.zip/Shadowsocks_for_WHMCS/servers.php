<?php 
/**
 * Shadowsocks for whmcs
 * 
 * @author Leepin <admin@cxsir.com>
 * @version 3.0.0
 * @copyright Copyright (c) Leepin
 * 
 */

/**
 * Common server configuration
 */
return array(
        array(
                'dbhost' => '',
                'dbname' => '',
                'dbuser' => '',
                'dbpass' => ''
            )
    );